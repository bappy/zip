//
//  gameViewController.h
//  challange.accepted
//
//  Created by bappy on 12/8/16.
//  Copyright © 2016 bappy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <XCDYouTubeKit/XCDYouTubeKit.h>
#import "ViewController.h"
@interface gameViewController : UIViewController
//@//property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activity;
//@property (weak, nonatomic) IBOutlet UIView *playerView;
//@property(nonatomic, strong) IBOutlet YTPlayerView *playerView;
@property (nonatomic) CAPSPageMenu *Menu;

@end
