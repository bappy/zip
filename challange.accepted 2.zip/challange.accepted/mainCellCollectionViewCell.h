//
//  mainCellCollectionViewCell.h
//  challange.accepted
//
//  Created by bappy on 12/2/16.
//  Copyright © 2016 bappy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mainCellCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIView *categoryLayer;
@property (weak, nonatomic) IBOutlet UIImageView *categoryImag;
@property (weak, nonatomic) IBOutlet UILabel *categorylabel;
@end
